def test_generic():
    assert 2==2